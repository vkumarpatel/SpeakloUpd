# Speaklo Redesign (Next.js + Tailwind)

## Quick start

1. npm install
2. npm run dev
3. Open http://localhost:3000